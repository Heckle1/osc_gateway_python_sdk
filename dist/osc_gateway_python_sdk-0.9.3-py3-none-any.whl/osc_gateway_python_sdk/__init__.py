from .outscale_gateway import OutscaleGateway as Gateway
